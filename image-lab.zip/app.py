from fastapi import FastAPI, UploadFile, File, Form, Request
from fastapi.responses import StreamingResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import io
from PIL import Image
import numpy as np
import cv2
from rembg import remove, new_session

SESSION = new_session("u2net")
app = FastAPI(title="Image Lab")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

def read_image_to_pil(upload: UploadFile) -> Image.Image:
    data = upload.file.read()
    img = Image.open(io.BytesIO(data)).convert("RGBA")
    return img

def pil_to_stream(img: Image.Image, fmt: str = "PNG"):
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    buf.seek(0)
    media = "image/png" if fmt.upper() == "PNG" else "image/jpeg"
    return StreamingResponse(buf, media_type=media)

def enhance_image_cv(pil_img: Image.Image) -> Image.Image:
    img = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)
    img = cv2.fastNlMeansDenoisingColored(img, None, 5, 5, 7, 21)
    blur = cv2.GaussianBlur(img, (0, 0), 1.2)
    sharp = cv2.addWeighted(img, 1.6, blur, -0.6, 0)
    lab = cv2.cvtColor(sharp, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    l2 = clahe.apply(l)
    lab2 = cv2.merge([l2, a, b])
    out = cv2.cvtColor(lab2, cv2.COLOR_LAB2BGR)
    out_rgb = cv2.cvtColor(out, cv2.COLOR_BGR2RGB)
    return Image.fromarray(out_rgb).convert("RGBA")

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/remove-bg")
async def remove_bg(file: UploadFile = File(...)):
    pil = read_image_to_pil(file)
    out = remove(pil, session=SESSION)
    return pil_to_stream(out, fmt="PNG")

@app.post("/enhance")
async def enhance(file: UploadFile = File(...)):
    pil = read_image_to_pil(file)
    out = enhance_image_cv(pil)
    return pil_to_stream(out, fmt="PNG")
